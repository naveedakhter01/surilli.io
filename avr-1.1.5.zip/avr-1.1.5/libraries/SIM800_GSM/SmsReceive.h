/*
  SmsReceive.h - Library for receiving message.
  Created by Silverback pvt limited, August 25, 2017.
  Released into the public domain.
*/



#ifndef SmsReceive_h
#define SmsReceive_h

#include "Arduino.h"


class SmsReceive
{
  public:
    SmsReceive(String num);
    char setuup();
	String exec();
    String mySerial_read();
  public:
    String _num = {"0"};
	String _msg = {"0"};
	char no[200]={0};
	char n[20] = {0};
	char ss[4]={0}; 
};

#endif
